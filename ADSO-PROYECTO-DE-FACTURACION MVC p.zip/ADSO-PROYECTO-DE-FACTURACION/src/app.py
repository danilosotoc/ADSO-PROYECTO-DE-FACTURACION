from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from db import db

app = Flask(__name__)
app.secret_key = 'clave_secreta'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/facturacion_2_0'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# Importar rutas (SIN src.)
from routes.productos import productos_bp
from routes.clientes import clientes_bp
from routes.vendedores import vendedores_bp
from routes.ventas import ventas_bp

# Registrar blueprints
app.register_blueprint(productos_bp)
app.register_blueprint(clientes_bp)
app.register_blueprint(vendedores_bp)
app.register_blueprint(ventas_bp)

@app.route('/')
def inicio():
    return '<h1>Bienvenido al sistema de facturación</h1><a href="/productos">Ir a Productos</a>'

# Probar conexión
with app.app_context():
    try:
        db.engine.execute("SELECT 1")
        print("Conexión exitosa a la base de datos")
    except Exception as e:
        print("Error de conexión:", e)

if __name__ == "__main__":
    app.run(debug=True)
