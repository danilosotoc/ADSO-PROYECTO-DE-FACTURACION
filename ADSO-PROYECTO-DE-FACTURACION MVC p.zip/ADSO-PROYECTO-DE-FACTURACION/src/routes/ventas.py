from flask import Blueprint, render_template, request, redirect, url_for
from src import db 
from src.models.venta import Venta
from src.models.cliente import Cliente
from src.models.vendedor import Vendedor
from src.models.producto import Producto

ventas_bp = Blueprint('ventas', __name__, url_prefix='/ventas')

@ventas_bp.route('/')
def index():
    ventas = Venta.query.all()
    clientes = Cliente.query.all()
    vendedores = Vendedor.query.all()
    productos = Producto.query.all()
    return render_template('gestion_ventas.html', ventas=ventas, clientes=clientes, vendedores=vendedores, productos=productos)

@ventas_bp.route('/crear', methods=['POST'])
def crear():
    cliente_id = request.form['cliente_id']
    vendedor_id = request.form['vendedor_id']
    producto_id = request.form['producto_id']
    cantidad = int(request.form['cantidad'])

    producto = Producto.query.get(producto_id)
    total = cantidad * producto.precio

    nueva_venta = Venta(cliente_id=cliente_id, vendedor_id=vendedor_id, producto_id=producto_id, cantidad=cantidad, total=total)
    db.session.add(nueva_venta)
    db.session.commit()
    return redirect(url_for('ventas.index'))
