from flask import Blueprint, render_template, request, redirect, url_for
from src import db
from src.models.producto import Producto

productos_bp = Blueprint('productos', __name__, url_prefix='/productos')

@productos_bp.route('/')
def index():
    productos = Producto.query.all()
    return render_template('gestion_productos.html', productos=productos)

@productos_bp.route('/crear', methods=['POST'])
def crear():
    nombre = request.form['nombre']
    precio = request.form['precio']
    nuevo = Producto(nombre=nombre, precio=precio)
    db.session.add(nuevo)
    db.session.commit()
    return redirect(url_for('productos.index'))

@productos_bp.route('/eliminar/<int:id>')
def eliminar(id):
    producto = Producto.query.get_or_404(id)
    db.session.delete(producto)
    db.session.commit()
    return redirect(url_for('productos.index'))
