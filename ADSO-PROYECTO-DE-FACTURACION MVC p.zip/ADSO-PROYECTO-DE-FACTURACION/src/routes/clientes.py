from flask import Blueprint, render_template, request, redirect, url_for
from src import db
from src.models.cliente import Cliente

clientes_bp = Blueprint('clientes', __name__, url_prefix='/clientes')

@clientes_bp.route('/')
def index():
    clientes = Cliente.query.all()
    return render_template('gestion_clientes.html', clientes=clientes)

@clientes_bp.route('/crear', methods=['POST'])
def crear():
    nombre = request.form['nombre']
    correo = request.form['correo']
    telefono = request.form['telefono']
    nuevo = Cliente(nombre=nombre, correo=correo, telefono=telefono)
    db.session.add(nuevo)
    db.session.commit()
    return redirect(url_for('clientes.index'))

@clientes_bp.route('/eliminar/<int:id>')
def eliminar(id):
    cliente = Cliente.query.get_or_404(id)
    db.session.delete(cliente)
    db.session.commit()
    return redirect(url_for('clientes.index'))

