from flask import Blueprint, render_template, request, redirect, url_for
from src import db
from src.models.vendedor import Vendedor

vendedores_bp = Blueprint('vendedores', __name__, url_prefix='/vendedores')

@vendedores_bp.route('/')
def index():
    vendedores = Vendedor.query.all()
    return render_template('gestion_vendedores.html', vendedores=vendedores)

@vendedores_bp.route('/crear', methods=['POST'])
def crear():
    nombre = request.form['nombre']
    correo = request.form['correo']
    telefono = request.form['telefono']
    nuevo = Vendedor(nombre=nombre, correo=correo, telefono=telefono)
    db.session.add(nuevo)
    db.session.commit()
    return redirect(url_for('vendedores.index'))

@vendedores_bp.route('/eliminar/<int:id>')
def eliminar(id):
    vendedor = Vendedor.query.get_or_404(id)
    db.session.delete(vendedor)
    db.session.commit()
    return redirect(url_for('vendedores.index'))
