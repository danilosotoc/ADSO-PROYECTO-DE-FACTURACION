document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("loginForm");
    if (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault();

            // Credenciales fijas
            const usuarioCorrecto = "admin";
            const contrasenaCorrecta = "1234";

            let usuario = document.getElementById("usuario").value;
            let contrasena = document.getElementById("contrasena").value;

            if (usuario === usuarioCorrecto && contrasena === contrasenaCorrecta) {
                sessionStorage.setItem("autenticado", "true"); // Guarda sesión
                window.location.href = "index.html"; // Redirige al menú
            } else {
                document.getElementById("error-msg").style.display = "block";
            }
        });
    }

    // Proteger el acceso al menú principal
    if (window.location.pathname.includes("index.html")) {
        if (!sessionStorage.getItem("autenticado")) {
            window.location.href = "login.html";
        }
    }
});

// Cerrar sesión
function cerrarSesion() {
    sessionStorage.removeItem("autenticado"); // Borra sesión
    window.location.href = "login.html"; // Redirige al login
}
