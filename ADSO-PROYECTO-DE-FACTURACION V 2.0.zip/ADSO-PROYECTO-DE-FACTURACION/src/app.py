from flask import Flask, render_template, redirect, url_for, request, session
from functools import wraps

app = Flask(__name__)
app.secret_key = 'clave-secreta'

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('autenticado'):
            return redirect(url_for('login_usuario'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login_usuario', methods=['GET', 'POST'])
def login_usuario():
    error = None
    if request.method == 'POST':
        usuario = request.form['usuario']
        contrasena = request.form['contrasena']
        if usuario == 'admin' and contrasena == '1234':
            session['autenticado'] = True
            return redirect(url_for('gestion_clientes'))
        else:
            error = 'Usuario o contraseña incorrectos'
    return render_template('login_usuario.html', error=error)

@app.route('/logout')
def logout():
    session.pop('autenticado', None)
    return redirect(url_for('login_usuario.html'))

@app.route('/')
@login_required
def gestion_clientes():
    return render_template('gestion_clientes.html')

@app.route('/gestion_clientes')
@login_required
def clientes_alias():
    return render_template('gestion_clientes.html')

@app.route('/gestion_productos')
@login_required
def gestion_productos():
    return render_template('gestion_productos.html')

@app.route('/gestion_vendedores')
@login_required
def gestion_vendedores():
    return render_template('gestion_vendedores.html')

@app.route('/gestiom_venta_y_facturacion')
@login_required
def gestion_venta_y_facturacion():
    return render_template('gestion_venta_y_facturacion.html')

if __name__ == '_main_':
    app.run(debug=True)
    